import VideoFeed from '../../components/VideoFeed';

export default function Home() {
  return <VideoFeed mode="public" emptyText="لا توجد فيديوهات بعد. سيظهر هنا كل ما ينشره الناس." />;
}
