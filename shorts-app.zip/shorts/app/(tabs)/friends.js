import VideoFeed from '../../components/VideoFeed';

export default function Friends() {
  return <VideoFeed mode="friends" emptyText="لا تتابع أحدًا بعد. تابع أشخاصًا لتظهر فيديوهاتهم هنا." />;
}
