import { useEffect, useRef, useState, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { supabase } from '../lib/supabase';
import { colors } from '../lib/theme';

function VideoItem({ item, active, height }) {
  const player = useVideoPlayer(item.video_url, (p) => { p.loop = true; });
  useEffect(() => { active ? player.play() : player.pause(); }, [active, player]);
  return (
    <View style={{ height, backgroundColor: '#000' }}>
      <VideoView player={player} style={StyleSheet.absoluteFill} contentFit="cover" nativeControls={false} />
      <View style={s.info}>
        <Text style={s.user}>@{item.profiles?.username ?? 'مستخدم'}</Text>
        {!!item.caption && <Text style={s.caption} numberOfLines={3}>{item.caption}</Text>}
      </View>
    </View>
  );
}

export default function VideoFeed({ mode = 'public', emptyText }) {
  const [videos, setVideos] = useState(null);
  const [activeId, setActiveId] = useState(null);
  const [height, setHeight] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    let q = supabase.from('videos').select('id, video_url, caption, user_id, profiles(username)')
      .order('created_at', { ascending: false }).limit(30);
    if (mode === 'friends') {
      const { data: { user } } = await supabase.auth.getUser();
      const { data: f } = await supabase.from('follows').select('following_id').eq('follower_id', user.id);
      const ids = (f ?? []).map((r) => r.following_id);
      if (!ids.length) { setVideos([]); return; }
      q = q.in('user_id', ids);
    }
    const { data } = await q;
    setVideos(data ?? []);
    if (data?.length) setActiveId((cur) => cur ?? data[0].id);
  }, [mode]);

  useEffect(() => { load(); }, [load]);

  const onViewable = useRef(({ viewableItems }) => {
    if (viewableItems[0]) setActiveId(viewableItems[0].item.id);
  }).current;

  return (
    <View style={s.page} onLayout={(e) => setHeight(e.nativeEvent.layout.height)}>
      {videos === null || !height ? (
        <ActivityIndicator color={colors.accent} style={{ flex: 1 }} />
      ) : videos.length === 0 ? (
        <View style={s.empty}><Text style={s.emptyText}>{emptyText}</Text></View>
      ) : (
        <FlatList
          data={videos}
          keyExtractor={(v) => v.id}
          renderItem={({ item }) => <VideoItem item={item} active={item.id === activeId} height={height} />}
          pagingEnabled
          snapToInterval={height}
          decelerationRate="fast"
          showsVerticalScrollIndicator={false}
          getItemLayout={(_, i) => ({ length: height, offset: height * i, index: i })}
          onViewableItemsChanged={onViewable}
          viewabilityConfig={{ itemVisiblePercentThreshold: 80 }}
          windowSize={3}
          refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.accent}
            onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }} />}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.bg },
  info: { position: 'absolute', bottom: 24, left: 16, right: 16 },
  user: { color: '#fff', fontSize: 17, fontWeight: '700', textAlign: 'right' },
  caption: { color: '#fff', fontSize: 15, marginTop: 6, textAlign: 'right' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  emptyText: { color: colors.muted, fontSize: 16, textAlign: 'center', lineHeight: 24 },
});
